document.addEventListener('DOMContentLoaded', function(){
  const btn = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if(btn && nav){
    btn.addEventListener('click', ()=> nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex');
  }
  document.getElementById('year').textContent = new Date().getFullYear();
});