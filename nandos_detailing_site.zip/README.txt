Nando’s Detailing Website
-------------------------

- Brand: Nando’s Detailing
- Theme: Purple & Black
- Contact: cahrlos3333@gmail.com | 832-264-5749
- Booking form included.

Setup:
1. Open index.html in a browser to preview.
2. To make the booking form work, replace the `action` in the form tag with your Formspree or Netlify Forms endpoint.
3. Host using GitHub Pages, Netlify, Vercel, or any static hosting.

